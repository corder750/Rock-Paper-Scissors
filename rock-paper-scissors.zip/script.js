var humanScore = 0;
var aiScore = 0;

function play(userChoice, isMultiplayer) {
	var computerChoice = Math.floor(Math.random() * 3); // Generates random number between 0 and 2
	if (computerChoice === 0) {
		computerChoice = "rock";
	} else if (computerChoice === 1) {
		computerChoice = "paper";
	} else {
		computerChoice = "scissors";
	}
	var resultDiv = document.getElementById("result");
	if (isMultiplayer) {
		resultDiv.innerHTML = determineWinner(userChoice, computerChoice);
	} else {
		resultDiv.innerHTML = determineWinnerSinglePlayer(userChoice, computerChoice);
	}
	updateScoreboard();
	checkGameOver();
}

function determineWinnerSinglePlayer(choice1, choice2) {
	if (choice1 === choice2) {
		return "Tie!";
	} else if (choice1 === "rock" && choice2 === "scissors" ||
		choice1 === "paper" && choice2 === "rock" ||
		choice1 === "scissors" && choice2 === "paper") {
		humanScore++;
		return "You Win!";
	} else {
		aiScore++;
		return "AI Wins!";
	}
}

function updateScoreboard() {
	var humanScoreSpan = document.getElementById("humanScore");
	var aiScoreSpan = document.getElementById("aiScore");
	humanScoreSpan.innerHTML = humanScore;
	aiScoreSpan.innerHTML = aiScore;
}

function checkGameOver() {
	if (humanScore === 10) {
		alert("Game over! You win!");
		resetScore();
	} else if (aiScore === 10) {
		alert("Game over! AI wins!");
		resetScore();
	}
}

function resetScore() {
	humanScore = 0;
	aiScore = 0;
	updateScoreboard();
}
